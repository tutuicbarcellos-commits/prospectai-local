# ProspectAI Local

Plataforma de prospecção comercial para freelancers, desenvolvedores de
sites, agências de marketing e pequenos negócios: pesquise empresas,
analise oportunidades, gere abordagens personalizadas com IA e acompanhe
tudo em um CRM visual (Kanban).

Esta é a versão **MVP** (ver escopo abaixo), construída para ser levada a
produção com poucos ajustes de configuração — sem código de exemplo ou
placeholders funcionais fora do que está explicitamente documentado.

## Stack

- **Next.js 14** (App Router) + **TypeScript**
- **Tailwind CSS** (tokens de design próprios, light/dark)
- **Supabase** (Postgres, Auth, Row Level Security)
- **Zod** para validação de todas as entradas
- **Route Handlers** para toda a lógica sensível (nunca no cliente)
- **Recharts** para os gráficos do dashboard
- Deploy recomendado: **Vercel**

## 1. Configurar o Supabase

1. Crie um projeto em [supabase.com](https://supabase.com).
2. No SQL Editor do projeto, cole e execute o conteúdo de
   `supabase/schema.sql`. Isso cria as tabelas, os enums, os índices, os
   triggers (incluindo a criação automática de perfil + assinatura Free
   no cadastro) e **todas as políticas de Row Level Security**.
3. Em **Authentication → URL Configuration**, defina a Site URL e adicione
   `http://localhost:3000/auth/callback` (e a URL de produção equivalente)
   como Redirect URL.
4. Em **Authentication → Email**, ative a confirmação de e-mail se desejar
   (o fluxo de cadastro já assume que ela pode estar ativada).
5. Copie a URL do projeto e a `anon public key` em **Project Settings → API**.

## 2. Variáveis de ambiente

Copie `.env.local.example` para `.env.local` e preencha:

```bash
cp .env.local.example .env.local
```

- `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY`: do passo 1.
- `ANTHROPIC_API_KEY`: necessária para o gerador de mensagens, a análise de
  empresas e o assistente de IA (`src/lib/ai/anthropic.ts`). Nunca é exposta
  ao navegador.
- `SUPABASE_SERVICE_ROLE_KEY`: reservada para jobs administrativos futuros
  que precisem contornar RLS (ex.: webhook de pagamento). Não é usada em
  nenhum caminho de código acessível pelo cliente hoje.
- `GOOGLE_PLACES_API_KEY`: opcional. Sem ela, a página de Prospecção
  mostra honestamente que a busca automática ainda não está conectada e
  oferece o cadastro manual — a plataforma nunca inventa empresas ou dados.

## 3. Rodando localmente

```bash
npm install
npm run dev
```

Acesse `http://localhost:3000`.

## 4. Deploy (Vercel)

1. Importe o repositório na Vercel.
2. Configure as mesmas variáveis de ambiente do `.env.local` em
   **Settings → Environment Variables**.
3. Deploy. `next.config.mjs` já define os headers de segurança
   (CSP, X-Frame-Options, HSTS em produção, etc.).

## Build na Vercel sem variáveis de ambiente configuradas

As páginas de autenticação (`/login`, `/cadastro`, `/recuperar-senha`,
`/redefinir-senha`) são Client Components, mas cada uma tem um `page.tsx`
em Server Component separado com `export const dynamic = "force-dynamic"`
(o formulário em si mora em `src/components/auth/*-form.tsx`). Isso
garante que elas nunca sejam pré-renderizadas estaticamente no build — o
cliente Supabase do navegador só é criado quando o formulário é enviado,
nunca durante `next build`. Resultado: o build nunca falha por falta de
`NEXT_PUBLIC_SUPABASE_URL`/`NEXT_PUBLIC_SUPABASE_ANON_KEY`, mesmo que você
ainda não tenha configurado as variáveis de ambiente no Vercel. Dito
isso, **o app só funciona de verdade com as variáveis reais configuradas**
— sem elas, o build passa, mas login/cadastro mostram erro ao tentar usar.

## Identidade visual

A paleta e alguns elementos de layout (o preview de leads no hero da
landing, o painel ao lado do formulário de login, as tags de
"temperatura" do lead) foram inspirados no posicionamento e na estrutura
do site da [LeadSite](https://useleadsite.com) — um produto do mesmo
nicho (prospecção de negócios locais sem site). Como a tela de login
deles bloqueia acesso automatizado, essa inspiração partiu do conteúdo
textual da home pública, não de um espelhamento pixel a pixel; as cores
exatas e a tipografia são autorais. Se quiser bater 100% com o visual
deles, me mande um print que eu ajusto os tokens em `src/app/globals.css`.

## Arquitetura e decisões de segurança

- **RLS em tudo.** Todas as tabelas com dados de usuário
  (`profiles`, `leads`, `interactions`, `ai_generations`, `subscriptions`,
  `audit_logs`) têm Row Level Security habilitado e políticas que
  restringem leitura/escrita a `auth.uid()`. O frontend nunca é a única
  linha de defesa.
- **Nada de `user_id` vindo do cliente.** Toda rota em `src/app/api/**`
  chama `requireUser()` (`src/lib/supabase/server.ts`), que resolve o
  usuário a partir do cookie de sessão. Nenhum handler usa um `user_id`
  ou plano enviado no corpo da requisição para decidir permissões ou
  limites.
- **IDOR.** Toda leitura/escrita de um recurso específico (`/api/leads/:id`)
  filtra por `id` **e** `user_id = auth.uid()` — um lead de outro usuário
  simplesmente não é encontrado (404), reforçando o que a RLS já impede no
  banco.
- **IA com contexto mínimo.** `src/lib/ai/anthropic.ts` e as rotas em
  `src/app/api/ai/**` nunca enviam a lista completa de leads do usuário
  para o modelo — apenas os campos do lead específico necessários para
  aquela tarefa. Os prompts instruem explicitamente a IA a nunca inventar
  dados que não foram fornecidos.
- **Rate limiting.** `src/lib/rate-limit.ts` limita login, cadastro,
  recuperação de senha, geração de IA, busca de prospecção e criação de
  leads. A implementação é em memória (adequada para uma instância única);
  para múltiplas instâncias em produção, troque por Upstash Redis mantendo
  a mesma assinatura de função.
- **Validação com Zod.** Toda entrada de usuário (`src/lib/validations/*`)
  é validada no servidor antes de tocar o banco — nunca se confia
  diretamente no que o navegador envia.
- **Planos aplicados no servidor.** Os limites de leads/mês e gerações de
  IA/mês (`PLAN_LIMITS` em `src/types/database.ts`) são checados nas rotas
  de API a partir da tabela `subscriptions` real — não é possível obter
  mais recursos alterando algo no navegador.
- **Sem segredos no cliente.** `ANTHROPIC_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
  e as futuras chaves de pagamento só existem em `process.env` do lado do
  servidor. `src/lib/ai/anthropic.ts` importa `server-only` para garantir
  isso em tempo de build.
- **Logs de auditoria.** `src/lib/audit-log.ts` registra ações sensíveis
  (criação/edição/exclusão de lead) sem nunca gravar senhas, tokens ou
  chaves.

## Testes de segurança (checklist manual)

1. **Usuário A tenta acessar um lead do usuário B** (`/leads/<id-de-outro-usuario>`
   ou `GET /api/leads/<id>`): esperado **404 — Lead não encontrado**, tanto
   pela RLS no banco quanto pelo filtro explícito por `user_id` na rota.
2. **Usuário altera manualmente o `user_id` enviado no corpo de um
   `POST /api/leads`**: o valor é ignorado — o servidor sempre grava
   `user_id: user.id` resolvido pela sessão, nunca o do corpo da requisição.

## Escopo do MVP (implementado)

Landing page · Cadastro · Login · Recuperação de senha · Dashboard ·
Cadastro manual de leads · Pipeline Kanban (drag and drop) · Página
detalhada do lead com timeline · Gerador de mensagens com IA · Análise de
oportunidade com IA · Assistente de IA · Supabase/Postgres/RLS ·
Validação com Zod · Rate limiting · Proteção de rotas · Sistema de
permissões (`user`/`admin` em `profiles.role`) · Modo claro/escuro ·
Responsividade completa.

## Roadmap (arquitetura já preparada)

- **Busca automática de empresas / Google Maps**: isolado em
  `searchProvider()` dentro de `src/app/api/prospect/search/route.ts` —
  basta implementar a chamada real quando `GOOGLE_PLACES_API_KEY` estiver
  configurada.
- **Pagamentos (Stripe / Mercado Pago)**: a tabela `subscriptions` já tem
  colunas `provider`, `provider_customer_id` e `provider_subscription_id`.
  A política de RLS da tabela propositalmente **não** permite insert/update
  pelo cliente — apenas um futuro webhook, autenticado com a service role
  key e validando a assinatura do webhook, poderá alterar o plano de um
  usuário.
- **WhatsApp / Instagram**: o gerador de mensagens já produz o texto;
  falta apenas a integração de envio.
- **Times / multiusuário**: `profiles.role` já distingue `user`/`admin`;
  falta o conceito de organização/equipe compartilhando leads.
- **Painel admin**: nenhuma rota admin existe ainda; ao criar uma, toda
  autorização deve ser validada no servidor via `profiles.role === "admin"`,
  nunca apenas no frontend.
