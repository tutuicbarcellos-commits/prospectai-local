import { Search, Radar, Sparkles, KanbanSquare, Handshake } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

const STEPS = [
  {
    icon: Search,
    title: "Encontre",
    description: "Pesquise empresas por categoria e localização.",
    benefit: "Pare de perder tempo procurando manualmente por potenciais clientes.",
  },
  {
    icon: Radar,
    title: "Descubra",
    description: "Analise a presença online e identifique oportunidades.",
    benefit: "Saiba onde existe espaço para oferecer seu serviço.",
  },
  {
    icon: Sparkles,
    title: "Personalize",
    description: "Use IA para criar uma abordagem adaptada à empresa.",
    benefit: "Envie mensagens que parecem realmente escritas para aquele negócio.",
  },
  {
    icon: KanbanSquare,
    title: "Organize",
    description: "Adicione o lead ao pipeline e acompanhe cada etapa.",
    benefit: "Nunca mais esqueça um contato ou um follow-up.",
  },
  {
    icon: Handshake,
    title: "Feche",
    description: "Acompanhe propostas e avance os leads até o fechamento.",
    benefit: "Tenha uma visão clara de tudo que está acontecendo na sua prospecção.",
  },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="mx-auto max-w-6xl px-6 py-20 md:py-24">
      <Reveal className="max-w-xl">
        <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
          Da primeira busca ao próximo cliente.
        </h2>
        <p className="mt-2 text-sm text-muted md:text-base">
          Um fluxo simples, do primeiro contato até o fechamento.
        </p>
      </Reveal>

      <div className="relative mt-12 grid gap-8 md:grid-cols-5">
        <div className="absolute left-0 right-0 top-5 hidden h-px bg-border md:block" />
        {STEPS.map((step, i) => (
          <Reveal key={step.title} delay={i * 90} className="relative">
            <div className="relative z-10 flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-surface shadow-card">
              <step.icon className="h-4 w-4 text-brand" />
            </div>
            <p className="mt-4 font-mono text-xs font-medium text-amber">
              {String(i + 1).padStart(2, "0")}
            </p>
            <h3 className="mt-1 font-display text-base font-semibold text-ink">{step.title}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-muted">{step.description}</p>
            <p className="mt-2 text-xs italic leading-relaxed text-ink/70">{step.benefit}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
