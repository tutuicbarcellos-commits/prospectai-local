import {
  Search,
  BarChart3,
  Sparkles,
  KanbanSquare,
  History,
  LayoutDashboard,
  TrendingUp,
  ListChecks,
  Workflow,
  MessageSquare,
} from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

const FEATURES = [
  { icon: Search, title: "Pesquisa de empresas", description: "Encontre negócios por segmento e localização." },
  { icon: BarChart3, title: "Análise de oportunidades", description: "Identifique empresas que podem precisar dos seus serviços." },
  { icon: Sparkles, title: "IA para mensagens", description: "Gere abordagens personalizadas em poucos segundos." },
  { icon: KanbanSquare, title: "Pipeline de vendas", description: "Organize cada oportunidade desde o primeiro contato até o fechamento." },
  { icon: History, title: "Histórico de contatos", description: "Tenha todas as interações organizadas." },
  { icon: LayoutDashboard, title: "Dashboard", description: "Veja rapidamente o que está acontecendo na sua prospecção." },
  { icon: TrendingUp, title: "Estatísticas", description: "Acompanhe conversão, oportunidades e evolução do funil." },
  { icon: ListChecks, title: "Próximas ações", description: "Saiba quem precisa de follow-up e o que fazer em seguida." },
];

const COMING_SOON = [
  { icon: Workflow, title: "Automação de follow-ups" },
  { icon: MessageSquare, title: "Integrações com WhatsApp" },
];

export function Features() {
  return (
    <section id="recursos" className="mx-auto max-w-6xl px-6 py-20 md:py-24">
      <Reveal className="max-w-xl">
        <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
          Tudo que você precisa para prospectar.
        </h2>
        <p className="mt-2 text-sm text-muted md:text-base">
          Um único lugar para encontrar, abordar e acompanhar clientes em potencial.
        </p>
      </Reveal>

      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((feature, i) => (
          <Reveal key={feature.title} delay={(i % 4) * 70}>
            <div className="group h-full rounded-lg border border-border bg-surface p-5 transition-colors hover:border-brand/40 hover:bg-brand-soft/30">
              <feature.icon className="h-5 w-5 text-brand" />
              <h3 className="mt-3 text-sm font-semibold text-ink">{feature.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-muted">{feature.description}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal className="mt-8">
        <div className="rounded-lg border border-dashed border-border p-5">
          <span className="inline-flex items-center rounded-md bg-amber-soft px-2 py-0.5 text-xs font-medium text-amber">
            Em breve
          </span>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {COMING_SOON.map((item) => (
              <div key={item.title} className="flex items-center gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-surface-raised text-muted">
                  <item.icon className="h-4 w-4" />
                </div>
                <p className="text-sm font-medium text-muted">{item.title}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </section>
  );
}
