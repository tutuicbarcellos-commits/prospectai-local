import { Check, Minus } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

type Cell = string | boolean;

const ROWS: { category: string; free: Cell; starter: Cell; pro: Cell; agency: Cell }[] = [
  { category: "Leads por mês", free: "20", starter: "200", pro: "1.000", agency: "3.000" },
  { category: "Gerações de IA", free: "10/mês", starter: "100/mês", pro: "Avançada", agency: "Avançada" },
  { category: "Pipeline", free: "Básico", starter: "Completo", pro: "Completo", agency: "Completo" },
  { category: "Análise de oportunidades", free: false, starter: true, pro: true, agency: true },
  { category: "Histórico completo", free: false, starter: false, pro: true, agency: true },
  { category: "Automação", free: false, starter: false, pro: "Mais automações", agency: "Avançada" },
  { category: "Equipe", free: "1 usuário", starter: "1 usuário", pro: "1 usuário", agency: "Em breve" },
  { category: "Suporte", free: "Padrão", starter: "Padrão", pro: "Padrão", agency: "Prioritário" },
];

function renderCell(cell: Cell) {
  if (typeof cell === "boolean") {
    return cell ? (
      <Check className="mx-auto h-4 w-4 text-brand" />
    ) : (
      <Minus className="mx-auto h-4 w-4 text-muted/50" />
    );
  }
  return <span>{cell}</span>;
}

export function PricingComparison() {
  return (
    <div className="mx-auto max-w-6xl px-6 pb-20 md:pb-24">
      <Reveal>
        <div className="overflow-x-auto rounded-xl border border-border bg-surface">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead>
              <tr className="border-b border-border text-xs uppercase tracking-wide text-muted">
                <th className="px-4 py-3 font-medium">Recurso</th>
                <th className="px-4 py-3 text-center font-medium">Free</th>
                <th className="px-4 py-3 text-center font-medium text-brand">Starter</th>
                <th className="px-4 py-3 text-center font-medium">Pro</th>
                <th className="px-4 py-3 text-center font-medium">Agency</th>
              </tr>
            </thead>
            <tbody>
              {ROWS.map((row) => (
                <tr key={row.category} className="border-b border-border last:border-0">
                  <td className="px-4 py-3 font-medium text-ink">{row.category}</td>
                  <td className="px-4 py-3 text-center text-muted">{renderCell(row.free)}</td>
                  <td className="bg-brand-soft/30 px-4 py-3 text-center text-ink">
                    {renderCell(row.starter)}
                  </td>
                  <td className="px-4 py-3 text-center text-muted">{renderCell(row.pro)}</td>
                  <td className="px-4 py-3 text-center text-muted">{renderCell(row.agency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Reveal>
    </div>
  );
}
