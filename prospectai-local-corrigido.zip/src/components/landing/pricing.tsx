"use client";

import * as React from "react";
import Link from "next/link";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/landing/reveal";
import { cn } from "@/lib/utils";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    description: "Para testar a plataforma",
    features: ["20 leads por mês", "Pipeline básico", "10 gerações de IA por mês"],
    highlighted: false,
    cta: "Começar grátis",
  },
  {
    id: "starter",
    name: "Starter",
    price: 29,
    description: "Para quem prospecta com regularidade",
    features: [
      "200 leads por mês",
      "Pipeline completo",
      "100 gerações de IA",
      "Análise de empresas",
    ],
    highlighted: true,
    badge: "Mais popular",
    cta: "Começar com Starter",
  },
  {
    id: "pro",
    name: "Pro",
    price: 59,
    description: "Para quem vive de prospecção",
    features: [
      "1.000 leads por mês",
      "IA avançada",
      "Análise de oportunidades",
      "Histórico completo",
      "Mais automações",
    ],
    highlighted: false,
    cta: "Começar com Pro",
  },
  {
    id: "agency",
    name: "Agency",
    price: 99,
    description: "Para agências e times",
    features: [
      "3.000 leads por mês",
      "Recursos avançados",
      "Mais usuários (em breve)",
      "Prioridade no suporte",
    ],
    highlighted: false,
    cta: "Começar com Agency",
  },
];

export function Pricing() {
  const [annual, setAnnual] = React.useState(false);

  return (
    <section id="precos" className="border-t border-border bg-surface-raised/40">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-24">
        <Reveal className="max-w-xl">
          <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
            Preços simples, sem surpresas.
          </h2>
          <p className="mt-2 text-sm text-muted md:text-base">
            Comece de graça e faça upgrade quando precisar de mais volume.
          </p>
        </Reveal>

        <Reveal delay={60}>
          <div className="mt-8 inline-flex items-center gap-1 rounded-lg border border-border bg-surface p-1 text-sm">
            <button
              type="button"
              onClick={() => setAnnual(false)}
              className={cn(
                "rounded-md px-3.5 py-1.5 font-medium transition-colors",
                !annual ? "bg-brand text-white" : "text-muted hover:text-ink"
              )}
            >
              Mensal
            </button>
            <button
              type="button"
              onClick={() => setAnnual(true)}
              className={cn(
                "flex items-center gap-1.5 rounded-md px-3.5 py-1.5 font-medium transition-colors",
                annual ? "bg-brand text-white" : "text-muted hover:text-ink"
              )}
            >
              Anual
              <span
                className={cn(
                  "rounded px-1.5 py-0.5 text-[10px] font-semibold",
                  annual ? "bg-white/20 text-white" : "bg-amber-soft text-amber"
                )}
              >
                Em breve
              </span>
            </button>
          </div>
        </Reveal>

        <div className="mt-8 grid gap-4 md:grid-cols-4">
          {PLANS.map((plan, i) => (
            <Reveal key={plan.id} delay={i * 70}>
              <div
                className={cn(
                  "flex h-full flex-col rounded-xl border bg-surface p-6",
                  plan.highlighted ? "border-brand shadow-popover" : "border-border"
                )}
              >
                {plan.badge && (
                  <span className="mb-3 inline-flex w-fit items-center rounded-md bg-brand-soft px-2 py-0.5 text-xs font-medium text-brand">
                    {plan.badge}
                  </span>
                )}
                <h3 className="font-display text-base font-semibold text-ink">{plan.name}</h3>
                <p className="mt-1 text-xs text-muted">{plan.description}</p>
                <p className="mt-4 font-display text-3xl font-medium text-ink">
                  R${plan.price}
                  <span className="text-sm font-normal text-muted">/mês</span>
                </p>
                {annual && plan.price > 0 && (
                  <p className="mt-1 text-xs text-muted">Cobrança anual em breve</p>
                )}
                <ul className="mt-5 flex-1 space-y-2.5">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm text-muted">
                      <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link href="/cadastro" className="mt-6">
                  <Button variant={plan.highlighted ? "primary" : "outline"} className="w-full">
                    {plan.cta}
                  </Button>
                </Link>
              </div>
            </Reveal>
          ))}
        </div>
        <p className="mt-6 text-xs text-muted">
          Pagamentos via Stripe ou Mercado Pago — em breve. Por enquanto, todas as contas
          começam no plano Free e o upgrade é feito diretamente com nosso time.
        </p>
      </div>
    </section>
  );
}
