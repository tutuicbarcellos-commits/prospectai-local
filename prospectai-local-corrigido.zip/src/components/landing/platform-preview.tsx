import { Search, BarChart3, Sparkles, KanbanSquare, MapPin, Star } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

export function PlatformPreview() {
  return (
    <section id="plataforma" className="border-t border-border bg-surface-raised/40">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-24">
        <Reveal className="max-w-xl">
          <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
            Por dentro da plataforma.
          </h2>
          <p className="mt-2 text-sm text-muted md:text-base">
            As telas reais que você vai usar todos os dias.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-5 lg:grid-cols-2">
          {/* Pesquisa */}
          <Reveal>
            <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-card">
              <div className="p-5 pb-0">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand-soft text-brand">
                  <Search className="h-4 w-4" />
                </div>
                <h3 className="mt-3 font-display text-base font-semibold text-ink">Pesquisa</h3>
                <p className="mt-1 text-sm text-muted">
                  Encontre empresas por segmento e localização em segundos.
                </p>
              </div>
              <div className="m-5 mt-4 rounded-lg border border-border bg-surface-raised/60 p-3">
                <div className="flex items-center gap-2 rounded-md border border-border bg-surface px-2.5 py-1.5 text-xs text-muted">
                  <Search className="h-3.5 w-3.5" /> Restaurantes em Porto Alegre
                </div>
                <div className="mt-2 space-y-1.5">
                  {["Cantina Bella Vista", "Sabor & Cia", "Empório Nova Esquina"].map((name) => (
                    <div
                      key={name}
                      className="flex items-center justify-between rounded-md bg-surface px-2.5 py-1.5 text-xs text-ink"
                    >
                      {name}
                      <MapPin className="h-3 w-3 text-muted" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          {/* Análise */}
          <Reveal delay={80}>
            <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-card">
              <div className="p-5 pb-0">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-amber-soft text-amber">
                  <BarChart3 className="h-4 w-4" />
                </div>
                <h3 className="mt-3 font-display text-base font-semibold text-ink">Análise</h3>
                <p className="mt-1 text-sm text-muted">
                  Veja o nível de oportunidade de cada empresa antes de abordar.
                </p>
              </div>
              <div className="m-5 mt-4 rounded-lg border border-border bg-surface-raised/60 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-ink">Studio Fit Pilates</p>
                  <span className="rounded-md bg-amber-soft px-2 py-0.5 text-[11px] font-medium text-amber">
                    Alta oportunidade
                  </span>
                </div>
                <div className="mt-3 space-y-1.5 text-xs text-muted">
                  <div className="flex items-center gap-1.5">
                    <Star className="h-3 w-3" /> Sem site próprio
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-3 w-3" /> Perfil desatualizado no Google
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          {/* IA */}
          <Reveal delay={160}>
            <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-card">
              <div className="p-5 pb-0">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand-soft text-brand">
                  <Sparkles className="h-4 w-4" />
                </div>
                <h3 className="mt-3 font-display text-base font-semibold text-ink">IA</h3>
                <p className="mt-1 text-sm text-muted">
                  Gere mensagens personalizadas para cada empresa em segundos.
                </p>
              </div>
              <div className="m-5 mt-4 rounded-lg border border-border bg-surface-raised/60 p-4">
                <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-brand">
                  <Sparkles className="h-3 w-3" /> Gerando mensagem...
                </p>
                <p className="text-xs leading-relaxed text-ink">
                  &ldquo;Oi! Tudo bem? Vi a empresa de vocês pelo Google e notei que
                  vocês ainda não têm site — tive uma ideia rápida que pode ajudar.&rdquo;
                </p>
              </div>
            </div>
          </Reveal>

          {/* Pipeline */}
          <Reveal delay={240}>
            <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-surface shadow-card">
              <div className="p-5 pb-0">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-amber-soft text-amber">
                  <KanbanSquare className="h-4 w-4" />
                </div>
                <h3 className="mt-3 font-display text-base font-semibold text-ink">Pipeline</h3>
                <p className="mt-1 text-sm text-muted">
                  Acompanhe cada lead do primeiro contato até o fechamento.
                </p>
              </div>
              <div className="m-5 mt-4 grid grid-cols-5 gap-1.5">
                {["Novo", "Contatado", "Respondeu", "Proposta", "Fechado"].map((stage, i) => (
                  <div key={stage} className="rounded-md bg-surface-raised/60 p-1.5 text-center">
                    <p className="truncate text-[9px] font-medium text-muted">{stage}</p>
                    <p className="mt-1 font-display text-xs font-semibold text-ink">
                      {[12, 7, 4, 2, 1][i]}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
