import { ChevronDown } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

const FAQS = [
  {
    question: "O que é o ProspectAI Local?",
    answer:
      "Uma plataforma para freelancers, agências e profissionais que vendem serviços para empresas locais encontrarem oportunidades, criarem abordagens com IA e organizarem sua prospecção em um único lugar.",
  },
  {
    question: "Para quem a plataforma foi criada?",
    answer:
      "Para quem vende serviços para negócios locais: freelancers, agências de marketing, desenvolvedores, consultores e times comerciais pequenos.",
  },
  {
    question: "Preciso saber programação?",
    answer: "Não. A plataforma foi feita para ser usada sem nenhum conhecimento técnico.",
  },
  {
    question: "Como a IA ajuda na prospecção?",
    answer:
      "A IA analisa as informações disponíveis sobre a empresa e gera mensagens de abordagem personalizadas, prontas para enviar por WhatsApp ou outro canal.",
  },
  {
    question: "Posso começar gratuitamente?",
    answer: "Sim. O plano Free inclui 20 leads e 10 gerações de IA por mês, sem cartão de crédito.",
  },
  {
    question: "Posso cancelar quando quiser?",
    answer: "Sim, não há fidelidade. Você pode cancelar ou voltar ao plano Free a qualquer momento.",
  },
  {
    question: "Meus dados ficam protegidos?",
    answer:
      "Sim. Seus dados e os dos seus leads são armazenados com segurança e não são compartilhados com terceiros.",
  },
  {
    question: "A plataforma garante que vou conseguir clientes?",
    answer:
      "O ProspectAI Local ajuda você a encontrar, analisar e organizar oportunidades. Ele não garante vendas ou determinado faturamento.",
  },
];

export function Faq() {
  return (
    <section id="faq" className="border-t border-border bg-surface-raised/40">
      <div className="mx-auto max-w-3xl px-6 py-20 md:py-24">
        <Reveal className="text-center">
          <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
            Perguntas frequentes
          </h2>
        </Reveal>

        <div className="mt-10 space-y-3">
          {FAQS.map((faq, i) => (
            <Reveal key={faq.question} delay={Math.min(i, 6) * 40}>
              <details className="group rounded-lg border border-border bg-surface open:border-brand/30">
                <summary className="focus-ring flex cursor-pointer list-none items-center justify-between gap-4 rounded-lg px-5 py-4 text-sm font-medium text-ink marker:content-none">
                  {faq.question}
                  <ChevronDown className="h-4 w-4 shrink-0 text-muted transition-transform group-open:rotate-180" />
                </summary>
                <p className="px-5 pb-4 text-sm leading-relaxed text-muted">{faq.answer}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
