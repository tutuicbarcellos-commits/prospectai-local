import Link from "next/link";
import {
  ArrowRight,
  Sparkles,
  MapPin,
  TrendingUp,
  Users,
  MessageCircle,
  Send,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const PIPELINE_STAGES = ["Novo", "Contatado", "Respondeu", "Proposta", "Fechado"];

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="bg-dot-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,black,transparent)]" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-brand/10 blur-3xl" />

      <div className="relative mx-auto max-w-6xl px-6 pb-20 pt-16 md:pt-24">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-6 inline-flex items-center gap-1.5 rounded-full border border-border bg-surface px-3 py-1 text-xs font-medium text-muted shadow-card">
            <span className="h-1.5 w-1.5 rounded-full bg-amber" />
            Plano gratuito disponível
          </div>
          <h1 className="font-display text-4xl font-medium leading-[1.08] tracking-tight text-ink md:text-5xl">
            Encontre oportunidades.{" "}
            <span className="text-brand">Aborde melhor.</span> Venda mais.
          </h1>
          <p className="mx-auto mt-5 max-w-lg text-base leading-relaxed text-muted md:text-lg">
            Encontre empresas locais, descubra oportunidades e gere abordagens
            personalizadas com IA — tudo em um único lugar.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link href="/cadastro">
              <Button size="lg">
                Começar gratuitamente <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <a href="#plataforma">
              <Button size="lg" variant="outline">
                Conhecer a plataforma
              </Button>
            </a>
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-muted">
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-brand" /> Sem cartão de crédito
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5 text-brand" /> Comece gratuitamente
            </span>
          </div>
        </div>

        {/* Product mockup composition */}
        <div className="relative mx-auto mt-16 max-w-4xl">
          <div className="overflow-hidden rounded-2xl border border-border bg-surface shadow-popover">
            <div className="flex items-center gap-1.5 border-b border-border bg-surface-raised px-4 py-3">
              <span className="h-2.5 w-2.5 rounded-full bg-danger/60" />
              <span className="h-2.5 w-2.5 rounded-full bg-amber/60" />
              <span className="h-2.5 w-2.5 rounded-full bg-brand/60" />
              <span className="ml-3 text-xs font-medium text-muted">
                app.prospectai.local/dashboard
              </span>
            </div>

            <div className="grid gap-4 p-5 md:grid-cols-[1.1fr_1fr] md:p-6">
              {/* Left column: dashboard stats + opportunity */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {[
                    { label: "Total de leads", value: "482", icon: Users },
                    { label: "Leads novos", value: "36", icon: Sparkles },
                    { label: "Contatados", value: "214", icon: MessageCircle },
                    { label: "Em negociação", value: "27", icon: TrendingUp },
                  ].map((stat) => (
                    <div
                      key={stat.label}
                      className="rounded-lg border border-border bg-surface-raised/60 p-3"
                    >
                      <stat.icon className="h-3.5 w-3.5 text-brand" />
                      <p className="mt-2 font-display text-lg font-semibold text-ink">
                        {stat.value}
                      </p>
                      <p className="text-[11px] leading-tight text-muted">{stat.label}</p>
                    </div>
                  ))}
                </div>

                <div className="rounded-lg border border-border p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-sm font-semibold text-ink">Clínica Vida</p>
                      <p className="flex items-center gap-1 text-xs text-muted">
                        <MapPin className="h-3 w-3" /> Porto Alegre, RS
                      </p>
                    </div>
                    <span className="shrink-0 rounded-md bg-amber-soft px-2 py-0.5 text-[11px] font-medium text-amber">
                      Alta oportunidade
                    </span>
                  </div>
                  <p className="mt-2 text-xs text-muted">Sem site cadastrado</p>

                  <div className="mt-3 rounded-md bg-surface-raised p-3">
                    <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-brand">
                      <Sparkles className="h-3 w-3" /> Mensagem gerada por IA
                    </p>
                    <p className="text-xs leading-relaxed text-ink">
                      &ldquo;Oi! Tudo bem? Vi a empresa de vocês...&rdquo;
                    </p>
                  </div>
                  <Button size="sm" className="mt-3 w-full">
                    <Send className="h-3.5 w-3.5" /> Adicionar ao pipeline
                  </Button>
                </div>
              </div>

              {/* Right column: pipeline */}
              <div className="rounded-lg border border-border p-4">
                <p className="mb-3 text-xs font-medium text-muted">Pipeline de oportunidades</p>
                <div className="space-y-2.5">
                  {PIPELINE_STAGES.map((stage, i) => (
                    <div
                      key={stage}
                      className="flex items-center justify-between rounded-md border border-border bg-surface-raised/50 px-3 py-2"
                    >
                      <span className="text-xs font-medium text-ink">{stage}</span>
                      <span
                        className={
                          i === PIPELINE_STAGES.length - 1
                            ? "rounded bg-brand-soft px-1.5 py-0.5 text-[10px] font-semibold text-brand"
                            : "text-[10px] font-medium text-muted"
                        }
                      >
                        {[12, 7, 4, 2, 1][i]}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-4 flex items-center gap-2 rounded-md border border-dashed border-border p-2.5 text-[11px] text-muted">
                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-brand" />
                  Proposta enviada para &ldquo;Studio Fit&rdquo; agora
                </div>
              </div>
            </div>
          </div>

          <div className="absolute -right-4 -top-4 hidden rotate-3 rounded-lg border border-border bg-surface px-3.5 py-2.5 shadow-popover sm:block">
            <p className="text-[11px] font-medium text-muted">Taxa de resposta</p>
            <p className="font-display text-lg font-semibold text-brand">20,4%</p>
          </div>
        </div>
      </div>
    </section>
  );
}
