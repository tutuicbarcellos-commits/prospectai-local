import { UserRound } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

const PLACEHOLDERS = [1, 2, 3];

export function Testimonials() {
  return (
    <section className="border-t border-border bg-surface-raised/40">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-24">
        <Reveal className="max-w-xl">
          <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
            Feito para quem vende serviços locais.
          </h2>
          <p className="mt-2 text-sm text-muted md:text-base">
            Espaço reservado para depoimentos reais de clientes — em breve.
          </p>
        </Reveal>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {PLACEHOLDERS.map((id, i) => (
            <Reveal key={id} delay={i * 90}>
              <div className="flex h-full flex-col justify-between rounded-xl border border-dashed border-border bg-surface p-6">
                <p className="text-sm italic leading-relaxed text-muted">
                  &ldquo;Depoimento de cliente&rdquo;
                </p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-surface-raised text-muted">
                    <UserRound className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-ink">Nome do cliente</p>
                    <p className="text-xs text-muted">Empresa / cidade</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
