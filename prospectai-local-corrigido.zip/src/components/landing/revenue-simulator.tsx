"use client";

import * as React from "react";
import { ArrowDown, Info } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";
import { formatCurrencyBRL } from "@/lib/utils";

export function RevenueSimulator() {
  const [leads, setLeads] = React.useState(50);
  const [taxaResposta, setTaxaResposta] = React.useState(20);
  const [taxaConversao, setTaxaConversao] = React.useState(10);
  const [valorServico, setValorServico] = React.useState(800);

  const respostas = Math.round((leads * taxaResposta) / 100);
  const clientes = Math.max(0, Math.round((respostas * taxaConversao) / 100));
  const vendas = clientes * valorServico;

  return (
    <section id="simulador" className="mx-auto max-w-6xl px-6 py-20 md:py-24">
      <Reveal className="max-w-xl">
        <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
          Quanto sua prospecção pode gerar?
        </h2>
        <p className="mt-2 text-sm text-muted md:text-base">
          A ferramenta ajuda você a organizar sua prospecção — ela não garante vendas.
          Ajuste os números abaixo para simular seu cenário.
        </p>
      </Reveal>

      <Reveal delay={80}>
        <div className="mt-10 grid gap-8 rounded-xl border border-border bg-surface p-6 shadow-card md:grid-cols-2 md:p-8">
          {/* Controls */}
          <div className="space-y-6">
            <SliderField
              label="Leads contatados por mês"
              value={leads}
              onChange={setLeads}
              min={10}
              max={500}
              step={10}
              suffix=""
            />
            <SliderField
              label="Taxa de resposta"
              value={taxaResposta}
              onChange={setTaxaResposta}
              min={0}
              max={100}
              step={1}
              suffix="%"
            />
            <SliderField
              label="Taxa de conversão"
              value={taxaConversao}
              onChange={setTaxaConversao}
              min={0}
              max={100}
              step={1}
              suffix="%"
            />
            <div>
              <label className="mb-1.5 flex items-center justify-between text-sm font-medium text-ink">
                Valor médio de um serviço
                <span className="font-display text-brand">{formatCurrencyBRL(valorServico)}</span>
              </label>
              <input
                type="range"
                min={100}
                max={10000}
                step={100}
                value={valorServico}
                onChange={(e) => setValorServico(Number(e.target.value))}
                className="w-full accent-brand"
                aria-label="Valor médio de um serviço"
              />
            </div>
          </div>

          {/* Result */}
          <div className="flex flex-col justify-center rounded-lg bg-surface-raised/60 p-6">
            <p className="text-center text-xs font-semibold uppercase tracking-wide text-muted">
              Simulação
            </p>
            <div className="mt-4 flex flex-col items-center gap-1.5">
              <ResultRow value={`${leads} leads`} />
              <ArrowDown className="h-4 w-4 text-muted" />
              <ResultRow value={`${respostas} respostas`} />
              <ArrowDown className="h-4 w-4 text-muted" />
              <ResultRow value={`${clientes} ${clientes === 1 ? "cliente" : "clientes"}`} />
              <ArrowDown className="h-4 w-4 text-muted" />
              <p className="mt-1 font-display text-3xl font-semibold text-brand">
                {formatCurrencyBRL(vendas)}
              </p>
              <p className="text-xs text-muted">em vendas simuladas</p>
            </div>
            <p className="mt-6 flex items-start gap-1.5 text-[11px] leading-relaxed text-muted">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              Simulação ilustrativa. Resultados reais variam de acordo com nicho, oferta,
              abordagem e execução.
            </p>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

function SliderField({
  label,
  value,
  onChange,
  min,
  max,
  step,
  suffix,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step: number;
  suffix: string;
}) {
  return (
    <div>
      <label className="mb-1.5 flex items-center justify-between text-sm font-medium text-ink">
        {label}
        <span className="font-display text-brand">
          {value}
          {suffix}
        </span>
      </label>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-brand"
        aria-label={label}
      />
    </div>
  );
}

function ResultRow({ value }: { value: string }) {
  return (
    <p className="rounded-md border border-border bg-surface px-3 py-1 text-sm font-medium text-ink">
      {value}
    </p>
  );
}
