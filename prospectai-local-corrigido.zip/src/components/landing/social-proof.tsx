import { Search, Sparkles, KanbanSquare, Clock } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

const ITEMS = [
  {
    icon: Search,
    title: "Busca inteligente",
    description: "Empresas organizadas por segmento e localização.",
  },
  {
    icon: Sparkles,
    title: "IA em segundos",
    description: "Mensagens personalizadas sem começar do zero.",
  },
  {
    icon: KanbanSquare,
    title: "Pipeline visual",
    description: "Todas as oportunidades em um único lugar.",
  },
  {
    icon: Clock,
    title: "Dados organizados",
    description: "Histórico e próximas ações sempre à mão.",
  },
];

export function SocialProof() {
  return (
    <section className="border-y border-border bg-surface-raised/50">
      <div className="mx-auto max-w-6xl px-6 py-16">
        <Reveal>
          <h2 className="text-center font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
            Tudo para transformar prospecção em oportunidade.
          </h2>
        </Reveal>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {ITEMS.map((item, i) => (
            <Reveal key={item.title} delay={i * 80}>
              <div className="h-full rounded-lg border border-border bg-surface p-5">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-brand-soft text-brand">
                  <item.icon className="h-4 w-4" />
                </div>
                <h3 className="mt-3.5 text-sm font-semibold text-ink">{item.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted">{item.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
