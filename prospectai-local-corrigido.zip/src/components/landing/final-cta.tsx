import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/landing/reveal";

export function FinalCta() {
  return (
    <section className="relative overflow-hidden border-t border-border bg-[#0B1020]">
      <div className="pointer-events-none absolute -bottom-32 left-1/2 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-brand/25 blur-3xl" />
      <div className="relative mx-auto max-w-3xl px-6 py-20 text-center md:py-24">
        <Reveal>
          <h2 className="font-display text-3xl font-medium tracking-tight text-white md:text-4xl">
            Sua próxima oportunidade pode estar a poucos cliques.
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-base leading-relaxed text-white/70">
            Encontre empresas, personalize sua abordagem e organize sua prospecção em um só
            lugar.
          </p>
          <div className="mt-8 flex flex-col items-center gap-3">
            <Link href="/cadastro">
              <Button size="lg" className="bg-amber text-ink hover:bg-amber/90">
                Começar gratuitamente <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <p className="text-xs text-white/50">Sem cartão de crédito.</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
