import { X, Check } from "lucide-react";
import { Reveal } from "@/components/landing/reveal";

const BEFORE = [
  "Pesquisar empresas manualmente",
  "Copiar informações à mão",
  "Escrever mensagens do zero",
  "Controlar leads em planilhas",
  "Esquecer follow-ups",
];

const AFTER = ["Encontrar", "Analisar", "Abordar", "Organizar", "Acompanhar"];

export function Differentiation() {
  return (
    <section className="border-t border-border bg-surface-raised/40">
      <div className="mx-auto max-w-6xl px-6 py-20 md:py-24">
        <Reveal className="max-w-xl">
          <h2 className="font-display text-2xl font-medium tracking-tight text-ink md:text-3xl">
            Menos planilhas. Menos abas. Mais prospecção.
          </h2>
        </Reveal>

        <div className="mt-10 grid gap-4 md:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-xl border border-border bg-surface p-6">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted">Antes</p>
              <ul className="mt-4 space-y-3">
                {BEFORE.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-muted">
                    <X className="mt-0.5 h-4 w-4 shrink-0 text-danger" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <div className="h-full rounded-xl border border-brand/30 bg-surface p-6 shadow-card">
              <p className="text-xs font-semibold uppercase tracking-wide text-brand">
                Com o ProspectAI Local
              </p>
              <ul className="mt-4 space-y-3">
                {AFTER.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm font-medium text-ink">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
