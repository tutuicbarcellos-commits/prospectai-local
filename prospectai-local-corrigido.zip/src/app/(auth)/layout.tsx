import Link from "next/link";
import { Radar } from "lucide-react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <div className="flex w-full flex-col justify-center px-6 py-12 sm:px-10 lg:w-[440px] lg:flex-none">
        <Link href="/" className="mb-10 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand text-white">
            <Radar className="h-4 w-4" />
          </div>
          <span className="font-display text-base font-semibold text-ink">
            ProspectAI Local
          </span>
        </Link>
        {children}
      </div>
      <div className="relative hidden flex-1 items-center justify-center bg-surface-raised lg:flex">
        <div className="max-w-md px-10">
          <p className="font-display text-2xl font-medium leading-snug text-ink">
            &ldquo;Consigo achar oportunidades e mandar a primeira mensagem em minutos, não em horas.&rdquo;
          </p>
          <p className="mt-4 text-sm text-muted">
            Desenvolvedor freelancer usando o ProspectAI Local para prospectar clientes locais.
          </p>
        </div>
      </div>
    </div>
  );
}
