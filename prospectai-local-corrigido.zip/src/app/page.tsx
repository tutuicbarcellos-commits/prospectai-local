import { LandingNav } from "@/components/landing/nav";
import { Hero } from "@/components/landing/hero";
import { SocialProof } from "@/components/landing/social-proof";
import { HowItWorks } from "@/components/landing/how-it-works";
import { PlatformPreview } from "@/components/landing/platform-preview";
import { Features } from "@/components/landing/features";
import { Differentiation } from "@/components/landing/differentiation";
import { RevenueSimulator } from "@/components/landing/revenue-simulator";
import { Testimonials } from "@/components/landing/testimonials";
import { Pricing } from "@/components/landing/pricing";
import { PricingComparison } from "@/components/landing/pricing-comparison";
import { Faq } from "@/components/landing/faq";
import { FinalCta } from "@/components/landing/final-cta";
import { Footer } from "@/components/landing/footer";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-canvas">
      <LandingNav />
      <Hero />
      <SocialProof />
      <HowItWorks />
      <PlatformPreview />
      <Features />
      <Differentiation />
      <RevenueSimulator />
      <Testimonials />
      <Pricing />
      <PricingComparison />
      <Faq />
      <FinalCta />
      <Footer />
    </div>
  );
}
