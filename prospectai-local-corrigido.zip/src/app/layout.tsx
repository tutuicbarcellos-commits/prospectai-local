import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "sonner";
import "./globals.css";

const display = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "600", "700"],
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600"],
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["400", "500"],
});

export const metadata: Metadata = {
  title: "ProspectAI Local — Encontre clientes e organize sua prospecção",
  description:
    "Encontre empresas locais, descubra oportunidades e gere abordagens personalizadas com IA. Organize seus leads e acompanhe suas vendas em um só lugar.",
  openGraph: {
    title: "ProspectAI Local — Encontre clientes e organize sua prospecção",
    description:
      "Encontre empresas locais, descubra oportunidades e gere abordagens personalizadas com IA. Organize seus leads e acompanhe suas vendas em um só lugar.",
    type: "website",
    locale: "pt_BR",
    siteName: "ProspectAI Local",
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="pt-BR"
      className={`${display.variable} ${body.variable} ${mono.variable}`}
      suppressHydrationWarning
    >
      <body className="font-sans antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background: "rgb(var(--color-surface))",
                border: "1px solid rgb(var(--color-border))",
                color: "rgb(var(--color-ink))",
              },
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
