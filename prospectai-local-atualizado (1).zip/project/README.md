# ProspectAI Local

Plataforma de prospecção comercial para freelancers, desenvolvedores de
sites, agências de marketing e pequenos negócios: pesquise empresas,
analise oportunidades, gere abordagens personalizadas com IA e acompanhe
tudo em um CRM visual (Kanban).

Esta é a versão **MVP** (ver escopo abaixo), construída para ser levada a
produção com poucos ajustes de configuração — sem código de exemplo ou
placeholders funcionais fora do que está explicitamente documentado.

## Stack

- **Next.js 14** (App Router) + **TypeScript**
- **Tailwind CSS** (tokens de design próprios, light/dark)
- **Supabase** (Postgres, Auth, Row Level Security)
- **Zod** para validação de todas as entradas
- **Route Handlers** para toda a lógica sensível (nunca no cliente)
- **Recharts** para os gráficos do dashboard
- Deploy recomendado: **Vercel**

## 1. Configurar o Supabase

1. Crie um projeto em [supabase.com](https://supabase.com).
2. No SQL Editor do projeto, cole e execute o conteúdo de
   `supabase/schema.sql`. Isso cria as tabelas, os enums, os índices, os
   triggers (incluindo a criação automática de perfil + assinatura Free
   no cadastro) e **todas as políticas de Row Level Security**.
3. Em **Authentication → URL Configuration**, defina a Site URL e adicione
   `http://localhost:3000/auth/callback` (e a URL de produção equivalente)
   como Redirect URL.
4. Em **Authentication → Email**, ative a confirmação de e-mail se desejar
   (o fluxo de cadastro já assume que ela pode estar ativada).
5. Copie a URL do projeto e a `anon public key` em **Project Settings → API**.

## 2. Variáveis de ambiente

Copie `.env.local.example` para `.env.local` e preencha:

```bash
cp .env.local.example .env.local
```

- `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY`: do passo 1.
- `ANTHROPIC_API_KEY`: necessária para o gerador de mensagens, a análise de
  empresas e o assistente de IA (`src/lib/ai/anthropic.ts`). Nunca é exposta
  ao navegador.
- `SUPABASE_SERVICE_ROLE_KEY`: reservada para jobs administrativos futuros
  que precisem contornar RLS (ex.: webhook de pagamento). Não é usada em
  nenhum caminho de código acessível pelo cliente hoje.
- `GOOGLE_PLACES_API_KEY`: opcional. Sem ela, a página de Prospecção
  mostra honestamente que a busca automática ainda não está conectada e
  oferece o cadastro manual — a plataforma nunca inventa empresas ou dados.
- `NEXT_PUBLIC_APP_URL`: URL pública do app (ex.: `http://localhost:3000`
  em dev, `https://prospectai-local.vercel.app` em produção). Usada só
  para montar as URLs de retorno do Checkout/Portal do Stripe.
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_STARTER`,
  `STRIPE_PRICE_PRO`, `STRIPE_PRICE_AGENCY`: opcionais. Sem elas, a área
  "Plano e uso" em Configurações mostra honestamente que os pagamentos
  ainda não estão ativos e nenhum botão de upgrade aparece. Veja a seção
  "Pagamentos (Stripe)" abaixo para o passo a passo completo.

## 3. Rodando localmente

```bash
npm install
npm run dev
```

Acesse `http://localhost:3000`.

## 4. Deploy (Vercel)

1. Importe o repositório na Vercel.
2. Configure as mesmas variáveis de ambiente do `.env.local` em
   **Settings → Environment Variables**.
3. Deploy. `next.config.mjs` já define os headers de segurança
   (CSP, X-Frame-Options, HSTS em produção, etc.).

## Arquitetura e decisões de segurança

- **RLS em tudo.** Todas as tabelas com dados de usuário
  (`profiles`, `leads`, `interactions`, `ai_generations`, `subscriptions`,
  `audit_logs`) têm Row Level Security habilitado e políticas que
  restringem leitura/escrita a `auth.uid()`. O frontend nunca é a única
  linha de defesa.
- **Nada de `user_id` vindo do cliente.** Toda rota em `src/app/api/**`
  chama `requireUser()` (`src/lib/supabase/server.ts`), que resolve o
  usuário a partir do cookie de sessão. Nenhum handler usa um `user_id`
  ou plano enviado no corpo da requisição para decidir permissões ou
  limites.
- **IDOR.** Toda leitura/escrita de um recurso específico (`/api/leads/:id`)
  filtra por `id` **e** `user_id = auth.uid()` — um lead de outro usuário
  simplesmente não é encontrado (404), reforçando o que a RLS já impede no
  banco.
- **IA com contexto mínimo.** `src/lib/ai/anthropic.ts` e as rotas em
  `src/app/api/ai/**` nunca enviam a lista completa de leads do usuário
  para o modelo — apenas os campos do lead específico necessários para
  aquela tarefa. Os prompts instruem explicitamente a IA a nunca inventar
  dados que não foram fornecidos.
- **Rate limiting.** `src/lib/rate-limit.ts` limita login, cadastro,
  recuperação de senha, geração de IA, busca de prospecção e criação de
  leads. A implementação é em memória (adequada para uma instância única);
  para múltiplas instâncias em produção, troque por Upstash Redis mantendo
  a mesma assinatura de função.
- **Validação com Zod.** Toda entrada de usuário (`src/lib/validations/*`)
  é validada no servidor antes de tocar o banco — nunca se confia
  diretamente no que o navegador envia.
- **Planos aplicados no servidor.** Os limites de leads/mês e gerações de
  IA/mês (`PLAN_LIMITS` em `src/types/database.ts`) são checados nas rotas
  de API a partir da tabela `subscriptions` real — não é possível obter
  mais recursos alterando algo no navegador.
- **Sem segredos no cliente.** `ANTHROPIC_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
  e as futuras chaves de pagamento só existem em `process.env` do lado do
  servidor. `src/lib/ai/anthropic.ts` importa `server-only` para garantir
  isso em tempo de build.
- **Logs de auditoria.** `src/lib/audit-log.ts` registra ações sensíveis
  (criação/edição/exclusão de lead) sem nunca gravar senhas, tokens ou
  chaves.

## Pagamentos (Stripe)

O upgrade de plano é feito dentro do produto, em **Configurações → Plano e
uso**, via Stripe Checkout, e só é ativado depois que o Stripe confirma o
pagamento por webhook — nunca só porque o usuário voltou para a página de
sucesso.

1. Crie uma conta em [stripe.com](https://stripe.com) (o modo de teste já
   serve para validar o fluxo inteiro).
2. Em **Product catalog**, crie três produtos recorrentes mensais —
   Starter (R$ 29), Pro (R$ 59) e Agency (R$ 99) — e copie o **Price ID**
   (`price_...`) de cada um.
3. Em **Developers → API keys**, copie a **Secret key** (`sk_...`).
4. Em **Developers → Webhooks**, adicione um endpoint apontando para
   `https://SEU-DOMINIO/api/webhooks/stripe` e selecione os eventos:
   `checkout.session.completed`, `customer.subscription.created`,
   `customer.subscription.updated`, `customer.subscription.deleted`,
   `invoice.payment_failed`. Copie o **Signing secret** (`whsec_...`).
5. Preencha no `.env.local` (e nas variáveis de ambiente da Vercel):
   `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_STARTER`,
   `STRIPE_PRICE_PRO`, `STRIPE_PRICE_AGENCY` e `NEXT_PUBLIC_APP_URL`.
6. Para testar localmente, use a
   [Stripe CLI](https://stripe.com/docs/stripe-cli):
   `stripe listen --forward-to localhost:3000/api/webhooks/stripe`.

Como funciona no código:

- `src/app/api/billing/checkout/route.ts` cria a sessão de Checkout —
  nunca aceita um preço vindo do navegador, sempre resolve o
  `STRIPE_PRICE_*` a partir do id do plano no servidor.
- `src/app/api/webhooks/stripe/route.ts` é a **única** rota do app com
  permissão para alterar o plano de um usuário. Ela autentica quem chama
  só pela assinatura do Stripe (`stripe-signature` + `STRIPE_WEBHOOK_SECRET`),
  nunca por sessão, e usa a service role key do Supabase (que ignora RLS)
  só para essa gravação específica.
- Cada handler do webhook grava um estado absoluto (plano X, status Y),
  então reenvios do mesmo evento pelo Stripe são seguros por construção
  (idempotentes) sem precisar de uma tabela de eventos processados.
- `src/app/api/billing/portal/route.ts` abre o Billing Portal do Stripe
  para cancelamento/gerenciamento — as regras de cancelamento e reembolso
  são as que você configurar no painel do Stripe, o app nunca promete
  nada além disso.

Mercado Pago **não** foi implementado — só o `MERCADOPAGO_ACCESS_TOKEN`
existe como variável reservada no `.env.local.example` para quando for
priorizado.

## Identidade visual

A marca (`src/components/logo.tsx`, usada também em `public/favicon.svg`)
é um pino de localização original cujo topo se abre em uma rede de três
pontos conectados — a mesma linguagem visual do ícone do assistente de
IA — com um ponto âmbar marcando a oportunidade encontrada. Índigo
`#6366F1` como cor principal, âmbar `#F59E0B` como destaque.



1. **Usuário A tenta acessar um lead do usuário B** (`/leads/<id-de-outro-usuario>`
   ou `GET /api/leads/<id>`): esperado **404 — Lead não encontrado**, tanto
   pela RLS no banco quanto pelo filtro explícito por `user_id` na rota.
2. **Usuário altera manualmente o `user_id` enviado no corpo de um
   `POST /api/leads`**: o valor é ignorado — o servidor sempre grava
   `user_id: user.id` resolvido pela sessão, nunca o do corpo da requisição.

## Escopo do MVP (implementado)

Landing page · Cadastro · Login · Recuperação de senha · Dashboard ·
Cadastro manual de leads · Pipeline Kanban (drag and drop) · Página
detalhada do lead com timeline · Gerador de mensagens com IA · Análise de
oportunidade com IA · Assistente de IA · Supabase/Postgres/RLS ·
Validação com Zod · Rate limiting · Proteção de rotas · Sistema de
permissões (`user`/`admin` em `profiles.role`) · Modo claro/escuro ·
Responsividade completa · Checkout, webhook e portal de assinatura do
Stripe (ativos assim que as credenciais forem configuradas) · Identidade
visual e logo originais.

## Roadmap (arquitetura já preparada)

- **Busca automática de empresas / Google Maps**: isolado em
  `searchProvider()` dentro de `src/app/api/prospect/search/route.ts` —
  basta implementar a chamada real quando `GOOGLE_PLACES_API_KEY` estiver
  configurada.
- **WhatsApp / Instagram**: o gerador de mensagens já produz o texto;
  falta apenas a integração de envio.
- **Times / multiusuário**: `profiles.role` já distingue `user`/`admin`;
  falta o conceito de organização/equipe compartilhando leads.
- **Painel admin**: nenhuma rota admin existe ainda; ao criar uma, toda
  autorização deve ser validada no servidor via `profiles.role === "admin"`,
  nunca apenas no frontend.
- **Mercado Pago**: variável reservada, sem implementação.
