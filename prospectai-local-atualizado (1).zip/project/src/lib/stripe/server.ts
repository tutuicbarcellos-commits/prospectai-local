import "server-only";
import Stripe from "stripe";

let _stripe: Stripe | null = null;

/**
 * Server-only Stripe client. `STRIPE_SECRET_KEY` nunca é lida no cliente
 * (este módulo tem `server-only`, que quebra o build se for importado de
 * um Client Component).
 */
export function getStripe(): Stripe {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error("STRIPE_SECRET_KEY não configurada no servidor");
  }
  if (!_stripe) {
    _stripe = new Stripe(key, {
      apiVersion: "2024-06-20",
      typescript: true,
    });
  }
  return _stripe;
}

export const PAID_PLANS = ["starter", "pro", "agency"] as const;
export type PaidPlanId = (typeof PAID_PLANS)[number];

function priceEnvMap(): Record<PaidPlanId, string | undefined> {
  return {
    starter: process.env.STRIPE_PRICE_STARTER,
    pro: process.env.STRIPE_PRICE_PRO,
    agency: process.env.STRIPE_PRICE_AGENCY,
  };
}

/** Resolve o Stripe Price ID configurado para um plano pago. Nunca aceita um preço vindo do cliente. */
export function priceIdForPlan(plan: PaidPlanId): string {
  const priceId = priceEnvMap()[plan];
  if (!priceId) {
    throw new Error(
      `Nenhuma variável STRIPE_PRICE_${plan.toUpperCase()} configurada no servidor.`
    );
  }
  return priceId;
}

/** Caminho inverso: a partir de um Stripe Price ID (vindo de um evento de webhook), descobre o plano. */
export function planForPriceId(priceId: string): PaidPlanId | null {
  const map = priceEnvMap();
  const match = (Object.entries(map) as [PaidPlanId, string | undefined][]).find(
    ([, id]) => id === priceId
  );
  return match ? match[0] : null;
}
