import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/types/database";

/**
 * Client Supabase com a service role key — ignora Row Level Security
 * por completo.
 *
 * NUNCA importe este módulo de uma rota que atende um pedido de usuário
 * comum. O único uso legítimo hoje é `src/app/api/webhooks/stripe/route.ts`,
 * que autentica quem chama pela assinatura do Stripe (não por sessão de
 * usuário) e por isso precisa, de forma legítima, escrever na assinatura
 * de outro usuário — algo que a política de RLS de `subscriptions`
 * propositalmente bloqueia para qualquer client autenticado como usuário.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY ou NEXT_PUBLIC_SUPABASE_URL não configurada no servidor"
    );
  }
  return createSupabaseClient<Database>(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
