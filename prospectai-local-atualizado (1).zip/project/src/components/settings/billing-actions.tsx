"use client";

import * as React from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import type { PlanId } from "@/types/database";

const UPGRADE_LABEL: Record<Extract<PlanId, "starter" | "pro" | "agency">, string> = {
  starter: "Fazer upgrade para Starter",
  pro: "Fazer upgrade para Pro",
  agency: "Fazer upgrade para Agency",
};

async function goTo(url: string) {
  window.location.href = url;
}

export function UpgradeButton({ plan }: { plan: "starter" | "pro" | "agency" }) {
  const [loading, setLoading] = React.useState(false);

  async function handleClick() {
    setLoading(true);
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan }),
      });
      const data = await res.json();
      if (!res.ok || !data.url) {
        toast.error(data.error ?? "Não foi possível iniciar o checkout.");
        setLoading(false);
        return;
      }
      await goTo(data.url);
    } catch {
      toast.error("Não foi possível iniciar o checkout.");
      setLoading(false);
    }
  }

  return (
    <Button size="sm" variant="outline" loading={loading} onClick={handleClick}>
      {UPGRADE_LABEL[plan]}
    </Button>
  );
}

export function ManageSubscriptionButton() {
  const [loading, setLoading] = React.useState(false);

  async function handleClick() {
    setLoading(true);
    try {
      const res = await fetch("/api/billing/portal", { method: "POST" });
      const data = await res.json();
      if (!res.ok || !data.url) {
        toast.error(data.error ?? "Não foi possível abrir o portal de cobrança.");
        setLoading(false);
        return;
      }
      await goTo(data.url);
    } catch {
      toast.error("Não foi possível abrir o portal de cobrança.");
      setLoading(false);
    }
  }

  return (
    <Button size="sm" variant="secondary" loading={loading} onClick={handleClick}>
      Gerenciar assinatura
    </Button>
  );
}
