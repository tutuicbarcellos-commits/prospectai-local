import { cn } from "@/lib/utils";

/**
 * Marca do ProspectAI Local: pino de localização em gradiente
 * índigo → violeta, com um círculo escuro no centro contendo uma seta
 * de envio em âmbar (a mensagem personalizada partindo do local
 * encontrado). Autocontida em cores — funciona sobre fundo claro ou
 * escuro sem precisar de uma base própria.
 */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 38"
      className={cn("h-8 w-[27px]", className)}
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="ProspectAI Local"
    >
      <defs>
        <linearGradient id="pal-pin" x1="5" y1="1" x2="27" y2="34" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#9C8CFB" />
          <stop offset="0.55" stopColor="#6C5CE0" />
          <stop offset="1" stopColor="#4338CA" />
        </linearGradient>
        <linearGradient id="pal-arrow" x1="10" y1="17.5" x2="21" y2="9" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#F59E0B" />
          <stop offset="1" stopColor="#FBBF54" />
        </linearGradient>
      </defs>

      <path
        d="M16 1.5C8.87 1.5 3.4 7.02 3.4 13.8c0 8.9 12.6 22.2 12.6 22.2s12.6-13.3 12.6-22.2C28.6 7.02 23.13 1.5 16 1.5Z"
        fill="url(#pal-pin)"
      />
      <path
        d="M16 1.5C11.2 1.5 7 4.6 5 9.1c2.7-3.2 6.7-4.9 11-4.9 6 0 11 3.9 12.3 9.3.2-1.8-.2-3.9-.9-5.6C25.4 4 21 1.5 16 1.5Z"
        fill="white"
        fillOpacity="0.18"
      />
      <circle cx="16" cy="14" r="7.6" fill="#211B42" />
      <path
        d="M10.6 15.9 21.4 9.3l-4.1 11.4-1.8-4.3-4.9-0.5Z"
        fill="url(#pal-arrow)"
        stroke="url(#pal-arrow)"
        strokeWidth="0.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function Logo({
  className,
  markClassName,
  wordmarkClassName,
}: {
  className?: string;
  markClassName?: string;
  wordmarkClassName?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <LogoMark className={markClassName} />
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-sm font-extrabold tracking-tight text-ink",
            wordmarkClassName
          )}
        >
          Prospect<span className="text-brand">AI</span>
        </span>
        <span className="mt-1 text-[9px] font-medium uppercase tracking-[0.35em] text-muted">
          Local
        </span>
      </span>
    </span>
  );
}
