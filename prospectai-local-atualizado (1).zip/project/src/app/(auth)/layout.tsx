import Link from "next/link";
import { Logo } from "@/components/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <div className="flex w-full flex-col justify-center px-6 py-12 sm:px-10 lg:w-[440px] lg:flex-none">
        <Link href="/" className="mb-10">
          <Logo wordmarkClassName="text-base" />
        </Link>
        {children}
      </div>
      <div className="relative hidden flex-1 items-center justify-center bg-surface-raised lg:flex">
        <div className="max-w-md px-10">
          <p className="font-display text-2xl font-medium leading-snug text-ink">
            Encontre oportunidades, personalize a abordagem com IA e acompanhe tudo em um
            pipeline visual.
          </p>
          <p className="mt-4 text-sm text-muted">
            Prospecção comercial para freelancers, agências e pequenos negócios que vendem
            para empresas locais.
          </p>
        </div>
      </div>
    </div>
  );
}
