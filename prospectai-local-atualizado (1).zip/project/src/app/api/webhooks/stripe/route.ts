import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { getStripe, planForPriceId } from "@/lib/stripe/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { PlanId, SubscriptionStatus } from "@/types/database";

export const dynamic = "force-dynamic";

/**
 * Webhook do Stripe — única rota do app com permissão para ativar ou
 * alterar o plano de um usuário.
 *
 * Autenticação: só o cabeçalho `stripe-signature`, verificado contra
 * `STRIPE_WEBHOOK_SECRET` com `stripe.webhooks.constructEvent`. Não há
 * cookie de sessão nem `user_id` de corpo de requisição envolvidos — se
 * a assinatura não bate, o evento é rejeitado antes de tocar o banco.
 *
 * Idempotência: cada handler abaixo grava um estado *absoluto* (plano X,
 * status Y) a partir do que o Stripe diz ser verdade agora — nunca um
 * incremento. Repetir o mesmo evento, ou receber eventos fora de ordem
 * para a mesma assinatura, converge para a mesma linha final em vez de
 * aplicar o efeito duas vezes.
 */

function mapStripeStatus(status: Stripe.Subscription.Status): SubscriptionStatus {
  switch (status) {
    case "active":
    case "trialing":
      return status;
    case "past_due":
    case "unpaid":
    case "incomplete_expired":
      return "past_due";
    default:
      // canceled, incomplete
      return "canceled";
  }
}

async function syncSubscriptionFromStripe(subscription: Stripe.Subscription) {
  const userId = subscription.metadata?.user_id;
  if (!userId) {
    console.error(
      "[stripe webhook] assinatura sem metadata.user_id — ignorando",
      subscription.id
    );
    return;
  }

  const priceId = subscription.items.data[0]?.price?.id;
  const resolvedPlan = priceId ? planForPriceId(priceId) : null;
  const plan: PlanId =
    subscription.status === "canceled" ? "free" : resolvedPlan ?? "free";
  const status = mapStripeStatus(subscription.status);

  const admin = createAdminClient();
  const { error } = await admin
    .from("subscriptions")
    .update({
      plan,
      status,
      provider: "stripe",
      provider_customer_id:
        typeof subscription.customer === "string"
          ? subscription.customer
          : subscription.customer.id,
      provider_subscription_id: subscription.id,
      updated_at: new Date().toISOString(),
    })
    .eq("user_id", userId);

  if (error) {
    console.error("[stripe webhook] falha ao gravar subscriptions", error);
    throw error;
  }
}

export async function POST(request: Request) {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) {
    console.error("[stripe webhook] STRIPE_WEBHOOK_SECRET não configurada");
    return NextResponse.json({ error: "Webhook não configurado" }, { status: 500 });
  }

  const signature = request.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json({ error: "Assinatura ausente" }, { status: 400 });
  }

  // Corpo cru — obrigatório para a verificação de assinatura do Stripe.
  const rawBody = await request.text();

  let event: Stripe.Event;
  try {
    event = getStripe().webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    console.error("[stripe webhook] assinatura inválida", err);
    return NextResponse.json({ error: "Assinatura inválida" }, { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        if (session.mode === "subscription" && session.subscription) {
          const subscriptionId =
            typeof session.subscription === "string"
              ? session.subscription
              : session.subscription.id;
          const subscription = await getStripe().subscriptions.retrieve(subscriptionId);
          await syncSubscriptionFromStripe(subscription);
        }
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await syncSubscriptionFromStripe(subscription);
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        if (invoice.subscription) {
          const subscriptionId =
            typeof invoice.subscription === "string"
              ? invoice.subscription
              : invoice.subscription.id;
          const subscription = await getStripe().subscriptions.retrieve(subscriptionId);
          await syncSubscriptionFromStripe(subscription);
        }
        break;
      }

      default:
        // Outros eventos são recebidos e ignorados deliberadamente.
        break;
    }
  } catch (err) {
    console.error("[stripe webhook] erro ao processar evento", event.type, err);
    // 500 faz o Stripe reenviar o evento mais tarde — correto aqui,
    // já que os handlers são idempotentes.
    return NextResponse.json({ error: "Erro ao processar evento" }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}
