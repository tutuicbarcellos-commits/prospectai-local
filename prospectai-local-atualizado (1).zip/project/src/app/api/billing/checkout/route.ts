import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser, UnauthorizedError } from "@/lib/supabase/server";
import { getStripe, priceIdForPlan, PAID_PLANS } from "@/lib/stripe/server";
import { rateLimit, RATE_LIMITS, rateLimitKey } from "@/lib/rate-limit";

const checkoutSchema = z.object({
  plan: z.enum(PAID_PLANS),
});

/**
 * Cria uma sessão de Checkout do Stripe para o plano escolhido.
 *
 * O preço nunca vem do corpo da requisição — só o id do plano, que é
 * resolvido no servidor para um Stripe Price ID configurado via
 * variável de ambiente (`priceIdForPlan`). O plano só é ativado de fato
 * quando o webhook confirmar o pagamento (`/api/webhooks/stripe`).
 */
export async function POST(request: Request) {
  try {
    const { user, supabase } = await requireUser();

    const limited = rateLimit(
      rateLimitKey(user.id, "billing:checkout"),
      RATE_LIMITS.billingCheckout
    );
    if (!limited.success) {
      return NextResponse.json(
        { error: "Muitas tentativas. Aguarde um minuto e tente novamente." },
        { status: 429 }
      );
    }

    const body = await request.json().catch(() => null);
    const parsed = checkoutSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Plano inválido." }, { status: 400 });
    }

    const appUrl = process.env.NEXT_PUBLIC_APP_URL;
    if (!appUrl) {
      return NextResponse.json(
        { error: "NEXT_PUBLIC_APP_URL não configurada no servidor." },
        { status: 500 }
      );
    }

    let priceId: string;
    try {
      priceId = priceIdForPlan(parsed.data.plan);
    } catch (err) {
      console.error("[POST /api/billing/checkout]", err);
      return NextResponse.json(
        { error: "Pagamentos ainda não estão configurados para este plano." },
        { status: 503 }
      );
    }

    const { data: existingSubscription } = await supabase
      .from("subscriptions")
      .select("provider_customer_id")
      .eq("user_id", user.id)
      .single();

    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      customer: existingSubscription?.provider_customer_id ?? undefined,
      customer_email: existingSubscription?.provider_customer_id ? undefined : user.email,
      client_reference_id: user.id,
      subscription_data: {
        metadata: { user_id: user.id, plan: parsed.data.plan },
      },
      metadata: { user_id: user.id, plan: parsed.data.plan },
      allow_promotion_codes: true,
      success_url: `${appUrl}/configuracoes?checkout=sucesso`,
      cancel_url: `${appUrl}/configuracoes?checkout=cancelado`,
    });

    if (!session.url) {
      return NextResponse.json(
        { error: "Não foi possível iniciar o checkout." },
        { status: 500 }
      );
    }

    return NextResponse.json({ url: session.url });
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
    }
    console.error("[POST /api/billing/checkout]", err);
    return NextResponse.json({ error: "Erro ao iniciar checkout." }, { status: 500 });
  }
}
