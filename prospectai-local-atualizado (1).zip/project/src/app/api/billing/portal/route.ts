import { NextResponse } from "next/server";
import { requireUser, UnauthorizedError } from "@/lib/supabase/server";
import { getStripe } from "@/lib/stripe/server";
import { rateLimit, RATE_LIMITS, rateLimitKey } from "@/lib/rate-limit";

/**
 * Abre o Billing Portal do Stripe para o cliente já existente, onde o
 * usuário pode atualizar forma de pagamento, trocar de plano ou
 * cancelar — tudo sob as regras reais do provedor, nunca simuladas aqui.
 */
export async function POST() {
  try {
    const { user, supabase } = await requireUser();

    const limited = rateLimit(
      rateLimitKey(user.id, "billing:portal"),
      RATE_LIMITS.billingPortal
    );
    if (!limited.success) {
      return NextResponse.json(
        { error: "Muitas tentativas. Aguarde um minuto e tente novamente." },
        { status: 429 }
      );
    }

    const appUrl = process.env.NEXT_PUBLIC_APP_URL;
    if (!appUrl) {
      return NextResponse.json(
        { error: "NEXT_PUBLIC_APP_URL não configurada no servidor." },
        { status: 500 }
      );
    }

    const { data: subscription } = await supabase
      .from("subscriptions")
      .select("provider_customer_id")
      .eq("user_id", user.id)
      .single();

    if (!subscription?.provider_customer_id) {
      return NextResponse.json(
        { error: "Nenhuma assinatura paga encontrada para gerenciar." },
        { status: 400 }
      );
    }

    const stripe = getStripe();
    const portalSession = await stripe.billingPortal.sessions.create({
      customer: subscription.provider_customer_id,
      return_url: `${appUrl}/configuracoes`,
    });

    return NextResponse.json({ url: portalSession.url });
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 });
    }
    console.error("[POST /api/billing/portal]", err);
    return NextResponse.json({ error: "Erro ao abrir o portal de cobrança." }, { status: 500 });
  }
}
